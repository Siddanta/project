<?php 
/* Template Name: Committee */
?>
<div class="committee-wrap">
<h3>Kesh bahadur k.c.</h3>
<div class="text-center">
<img class="rounded" src="http://ksnepal-new.loc/wp-content/uploads/2020/03/advance-package-bg.jpg" alt="members"/>
<h4>9856026090</h4>
<h4>Parbat</h4>
</div>
</div>